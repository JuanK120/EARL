class CF:

    def __init__(self, fact, recourse, cf, rewards, value=0):

        self.fact = fact
        self.recourse = recourse
        self.cf = cf
        self.reward_dict = rewards
        self.value = value



